# ProjetWeb
Projet final en web de la deuxième année licence Informatique.
###Signe-moi
Une application web pour traduir le français en langue des signes française.
###!instructions:
-Pour l'ajout d'un mot et de sa vidéo, il faut mettre la une vidéo de type webm dans le dossier test.

