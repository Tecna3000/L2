# TP langages formels

TP langages formels
### Membres du groupe:
- Meriem Ramdani
- Adam Alami

## Les tests:
- test/test1.ap abba
  Yes
- test/test1.ap ba
  No
- test/test2.ap abaabb 
  Yes
- test/test2.ap ab
  No
- test/test3.ap abb
  Yes
- test/test3.ap,aba
  No
- test/test1.gr yz 
  Yes
- test/test2.gr ()()
  Yes
- test/test3.gr (())
  Yes
    